package com.aodhorizon.anjay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.TextSwitcher
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var hourSwitcher: TextSwitcher
    private lateinit var minuteSwitcher: TextSwitcher
    private lateinit var secondSwitcher: TextSwitcher
    private lateinit var batteryView: BatteryView
    private lateinit var batteryText: TextView

    private var lastHour = -1
    private var lastMinute = -1
    private var lastSecond = -1

    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = object : Runnable {
        override fun run() {
            updateTime()
            handler.postDelayed(this, 1000)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            
            if (level != -1 && scale != -1) {
                val batteryPct = (level.toFloat() / scale.toFloat() * 100).toInt()
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || 
                                 status == BatteryManager.BATTERY_STATUS_FULL
                updateBatteryUI(batteryPct, isCharging)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        hideSystemUI()

        hourSwitcher = findViewById(R.id.hourSwitcher)
        minuteSwitcher = findViewById(R.id.minuteSwitcher)
        secondSwitcher = findViewById(R.id.secondSwitcher)
        batteryView = findViewById(R.id.batteryView)
        batteryText = findViewById(R.id.batteryText)

        setupSwitcher(hourSwitcher)
        setupSwitcher(minuteSwitcher)
        setupSwitcher(secondSwitcher)

        handler.post(tickRunnable)
        
        // Register battery receiver
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun setupSwitcher(switcher: TextSwitcher) {
        switcher.setFactory {
            TextView(this@MainActivity).apply {
                gravity = Gravity.CENTER
                textSize = 100f
                setTextColor(android.graphics.Color.WHITE)
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
        }

        val inAnim = AnimationUtils.loadAnimation(this, R.anim.slide_in_up)
        val outAnim = AnimationUtils.loadAnimation(this, R.anim.slide_out_up)

        switcher.inAnimation = inAnim
        switcher.outAnimation = outAnim
    }

    private fun updateTime() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)

        if (hour != lastHour) {
            hourSwitcher.setText(String.format(Locale.getDefault(), "%02d", hour))
            lastHour = hour
        }

        if (minute != lastMinute) {
            minuteSwitcher.setText(String.format(Locale.getDefault(), "%02d", minute))
            lastMinute = minute
        }

        if (second != lastSecond) {
            secondSwitcher.setText(String.format(Locale.getDefault(), "%02d", second))
            lastSecond = second
        }
    }

    private fun updateBatteryUI(percent: Int, isCharging: Boolean) {
        batteryView.setBatteryLevel(percent)
        batteryView.setIsCharging(isCharging)
        batteryText.text = String.format(Locale.getDefault(), "%d%%", percent)
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(tickRunnable)
        unregisterReceiver(batteryReceiver)
    }
}
