package com.aodhorizon.anjay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class BatteryView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var batteryLevel = 0
    private var isCharging = false
    
    private val strokeWidth = 4f
    private val cornerRadius = 6f
    private val padding = 6f
    
    private val bodyRect = RectF()
    private val capRect = RectF()
    private val fillRect = RectF()
    private val boltPath = Path()

    fun setBatteryLevel(level: Int) {
        batteryLevel = level
        invalidate()
    }

    fun setIsCharging(charging: Boolean) {
        isCharging = charging
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()
        
        if (width == 0f || height == 0f) return

        val capWidth = width * 0.08f
        val bodyWidth = width - capWidth
        
        // 1. Gambar Body Baterai (Outer Frame)
        paint.color = Color.WHITE
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        bodyRect.set(strokeWidth/2, strokeWidth/2, bodyWidth, height - strokeWidth/2)
        canvas.drawRoundRect(bodyRect, cornerRadius, cornerRadius, paint)
        
        // 2. Gambar Kepala Baterai (Cap)
        paint.style = Paint.Style.FILL
        capRect.set(bodyWidth, height * 0.35f, width, height * 0.65f)
        canvas.drawRoundRect(capRect, 2f, 2f, paint)
        
        // 3. Gambar Isi Baterai (Fill)
        if (batteryLevel > 0) {
            val maxFillWidth = bodyWidth - (strokeWidth + padding) * 2
            val fillWidth = maxFillWidth * (batteryLevel / 100f)
            
            val verticalPadding = if (batteryLevel < 40) {
                (height * 0.2f) + padding 
            } else {
                strokeWidth + padding
            }

            fillRect.set(
                strokeWidth + padding,
                verticalPadding,
                strokeWidth + padding + fillWidth,
                height - verticalPadding
            )
            
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            canvas.drawRoundRect(fillRect, 4f, 4f, paint)
        }

        // 4. Gambar Petir jika sedang charging
        if (isCharging) {
            drawLightningBolt(canvas, bodyWidth / 2, height / 2, height * 0.6f)
        }
    }

    private fun drawLightningBolt(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        paint.color = Color.WHITE
        paint.style = Paint.Style.FILL
        
        boltPath.reset()
        // Koordinat relatif untuk membuat bentuk petir
        boltPath.moveTo(cx + size * 0.1f, cy - size * 0.5f)
        boltPath.lineTo(cx - size * 0.3f, cy + size * 0.1f)
        boltPath.lineTo(cx - size * 0.05f, cy + size * 0.1f)
        boltPath.lineTo(cx - size * 0.1f, cy + size * 0.5f)
        boltPath.lineTo(cx + size * 0.3f, cy - size * 0.1f)
        boltPath.lineTo(cx + size * 0.05f, cy - size * 0.1f)
        boltPath.close()
        
        // Beri sedikit stroke hitam di ptirnya biar agak jelas
        val originalColor = paint.color
        paint.color = Color.BLACK
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        canvas.drawPath(boltPath, paint)
        
        paint.color = originalColor
        paint.style = Paint.Style.FILL
        canvas.drawPath(boltPath, paint)
    }
}
